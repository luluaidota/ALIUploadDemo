//
//  AlivcKeyboardManageViewController.h
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/4/9.
//  Copyright © 2018年 Alibaba. All rights reserved.
//  集成了键盘管理的父类，自身以及子类自动集成键盘管理

#import "AlivcBaseViewController.h"

@interface AlivcKeyboardManageViewController : AlivcBaseViewController

@end
