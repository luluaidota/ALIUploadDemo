//
//  AlivcDefine.m
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/5/9.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "AlivcDefine.h"


//资源删除通知
NSString * const AliyunEffectResourceDeleteNotification = @"AliyunEffectResourceDeleteNotification";
//系统字体名称
NSString * const AlivcSystemFontName = @"PingFangSC-Regular";

@implementation AlivcDefine

@end

