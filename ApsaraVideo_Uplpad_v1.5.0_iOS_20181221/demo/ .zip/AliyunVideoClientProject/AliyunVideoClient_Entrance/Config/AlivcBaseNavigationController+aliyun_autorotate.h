//
//  AlivcBaseNavigationController+aliyun_autorotate.h
//  AliyunVideoClient_Entrance
//
//  Created by 王凯 on 2018/5/31.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "AlivcBaseNavigationController.h"

@interface AlivcBaseNavigationController (aliyun_autorotate)

@end
