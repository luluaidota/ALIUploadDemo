//
//  AlivcDefine.h
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/5/9.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>



//资源删除通知
extern NSString * const AliyunEffectResourceDeleteNotification;
//系统字体名称
extern NSString * const AlivcSystemFontName;

@interface AlivcDefine : NSObject
@end
