//
//  AlivcBeautifyDefaultControl.h
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/7/20.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AlivcPushBeautyParams.h"

@interface AlivcBeautifyDefaultControl : NSObject

@end
