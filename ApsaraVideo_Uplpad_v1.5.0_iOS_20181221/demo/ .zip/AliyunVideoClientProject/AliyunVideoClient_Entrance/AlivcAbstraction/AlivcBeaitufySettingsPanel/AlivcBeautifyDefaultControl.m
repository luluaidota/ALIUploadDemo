//
//  AlivcBeautifyDefaultControl.m
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/7/20.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "AlivcBeautifyDefaultControl.h"
#import "NSString+AlivcHelper.h"

@implementation AlivcBeautifyDefaultControl

@end
