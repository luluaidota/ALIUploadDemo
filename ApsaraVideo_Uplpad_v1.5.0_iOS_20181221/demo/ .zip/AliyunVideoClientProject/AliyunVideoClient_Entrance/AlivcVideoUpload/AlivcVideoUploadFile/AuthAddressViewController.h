//
//  STSViewController.h
//  VODUploadDemo
//
//  Created by Worthy on 2018/1/5.
//

#import <UIKit/UIKit.h>


@interface AuthAddressViewController : UIViewController
@end
