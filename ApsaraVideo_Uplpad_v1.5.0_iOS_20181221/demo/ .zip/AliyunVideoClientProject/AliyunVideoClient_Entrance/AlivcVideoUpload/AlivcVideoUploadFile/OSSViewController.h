//
//  OSSViewController.h
//  VODUploadDemo
//
//  Created by Worthy on 2018/1/8.
//

#import <UIKit/UIKit.h>

/**
 使用sts方式上传到oss
 建议直接使用AliyunOSSiOS提供的接口上传到oss
 */
@interface OSSViewController : UIViewController

@end
