//
//  MainViewController.h
//  VODUploadDemo
//
//  Created by Worthy on 2018/1/5.
//  上传主界面

#import <UIKit/UIKit.h>

@interface AlivcUploadMainViewController : UIViewController

@end
