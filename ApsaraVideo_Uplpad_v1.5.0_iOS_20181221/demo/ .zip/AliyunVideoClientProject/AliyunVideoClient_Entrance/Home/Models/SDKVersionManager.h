//
//  SDKVersionManager.h
//  AliyunVideoClient_Entrance
//
//  Created by 舒毅文 on 2018/11/6.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SDKVersionManager : NSObject

+ (void)printAllSDKVersion;

@end

NS_ASSUME_NONNULL_END
