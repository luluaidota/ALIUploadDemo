//
//  AVC_ET_HomeViewController.h
//  AliyunVideoClient_Entrance
//
//  Created by Zejian Cai on 2018/3/22.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "AlivcBaseViewController.h"

@interface AlivcHomeViewController : AlivcBaseViewController

@end
